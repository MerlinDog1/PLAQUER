import { GoogleGenAI, Type } from "@google/genai";
import { AVAILABLE_FONTS, PlaqueState, Shape, Material, Fixing } from "../types";

// Helper to interact with Google GenAI
const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// Retry helper for 503 Overloaded errors
const retryWrapper = async <T>(
  operation: () => Promise<T>, 
  retries = 5, 
  baseDelay = 2000
): Promise<T> => {
  try {
    return await operation();
  } catch (error: any) {
    // Check various error formats for 503/Overloaded
    // The API might return { error: { code: 503, message: "...", status: "UNAVAILABLE" } }
    const isOverloaded = 
      error.status === 503 || 
      error.code === 503 || 
      (error.message && error.message.toLowerCase().includes("overloaded")) ||
      (error.message && error.message.includes("503")) ||
      (error.error && (error.error.code === 503 || error.error.status === "UNAVAILABLE"));

    if (retries > 0 && isOverloaded) {
      console.warn(`Model overloaded (503). Retrying in ${baseDelay}ms... (${retries} attempts left)`);
      await new Promise(resolve => setTimeout(resolve, baseDelay));
      // Use 1.5x backoff to avoid waiting too long on many retries
      return retryWrapper(operation, retries - 1, baseDelay * 1.5);
    }
    throw error;
  }
};

export const generateLayout = async (
  promptText: string,
  width: number,
  height: number,
  shape: Shape,
  currentSvgContent?: string | null
): Promise<{ svgContent: string; reasoning: string } | null> => {
  const ai = getAIClient();
  const fontList = AVAILABLE_FONTS.join(", ");
  
  let margin = 20; 
  if (shape !== Shape.Rect) margin = 40;
  const safeW = width - margin * 2;
  const safeH = height - margin * 2;

  const systemPrompt = `
    Act as a Professional Typesetter and Copy Editor.
    Canvas: ${width}x${height}mm. Safe Zone: ${safeW}x${safeH}mm.
    Available Fonts: ${fontList}.
    
    Instructions:
    1. **Text Correction (CRITICAL):**
       - Fix any spelling errors or typos in the user's request.
       - Apply proper capitalization automatically:
         - Capitalize names (e.g., "john smith" -> "John Smith").
         - Capitalize months, days, and holidays (e.g., "january" -> "January").
         - Capitalize proper nouns and places.
         - Use Title Case for main headers.
    2. Create an elegant typographic layout using the corrected text.
    3. Center everything (0,0 is the center of the text group).
    4. Use <text> and <tspan> elements.
    5. Set fill="#2b1d0e" (Deep Etch Color).
    6. Return ONLY valid SVG group content (content inside a <g> tag), do not return the full <svg> wrapper.
    7. Establish clear visual hierarchy (Header vs Body).
    ${currentSvgContent ? "8. IMPORTANT: The user is providing EXISTING SVG content. You must MODIFY it based on their new request. Do not completely discard the old design unless asked." : ""}
  `;

  let userContent = "";
  if (currentSvgContent) {
    userContent = `CURRENT_DESIGN:\n${currentSvgContent}\n\nUSER_REQUEST: "${promptText}"\n\nTask: Update the design based on the request.`;
  } else {
    userContent = `Request: "${promptText}".`;
  }

  try {
    const response = await retryWrapper(async () => {
      return await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: userContent,
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reasoning: { type: Type.STRING, description: "Short explanation of design choices, corrections, or changes made" },
              svgContent: { type: Type.STRING, description: "The inner SVG XML string (g elements)" }
            },
            required: ["reasoning", "svgContent"]
          }
        }
      });
    });

    const text = response.text;
    if (!text) throw new Error("No text returned from API");
    return JSON.parse(text);

  } catch (error) {
    console.error("Layout generation failed:", error);
    throw error; // Propagate error for 403/500 handling in UI
  }
};

export const generateRealisticView = async (
  svgBase64: string,
  state: PlaqueState
): Promise<string | null> => {
  const ai = getAIClient();
  
  // 1. Rich Material Definitions
  const materials = {
    [Material.BrushedBrass]: {
      name: "Brushed Brass",
      hex: "#D4AF37",
      texture: "Horizontal brushed metal grain",
      details: "Satin finish, soft linear reflections, premium gold tone"
    },
    [Material.PolishedBrass]: {
      name: "Polished Brass",
      hex: "#F5E050",
      texture: "Mirror-smooth",
      details: "High-gloss, highly reflective, mirror finish gold"
    },
    [Material.AgedBrass]: {
      name: "Aged Antique Brass",
      hex: "#8B6F4E",
      texture: "Weathered patina",
      details: "Matte finish, uneven oxidation, vintage bronze/brown tones"
    },
    [Material.BrushedSteel]: {
      name: "Brushed Stainless Steel",
      hex: "#C0C0C0",
      texture: "Horizontal brushed metal grain",
      details: "Satin finish, industrial silver tone, sharp highlights"
    },
    [Material.PolishedSteel]: {
      name: "Polished Chrome",
      hex: "#E0E0E0",
      texture: "Mirror-smooth",
      details: "High-gloss, chrome reflectivity, cool silver tone"
    },
  };

  const mat = materials[state.material];
  
  // 2. Dynamic Object Description
  const shapeDesc = state.shape === Shape.Rect 
    ? (state.cornerRadius > 0 ? "Rounded Rectangle" : "Sharp Rectangle") 
    : (state.shape === Shape.Circle ? "Circle" : "Oval");

  let backingDesc = "None (Mounted directly to wall)";
  if (state.wood) {
    const tone = state.woodTone === 'dark' ? "Dark Walnut" : "Light Oak";
    const edge = state.woodEdge === 'bevel' ? "beveled" : "square";
    
    // Determine backing shape based on plaque shape
    let backingShape = "Rectangular";
    if (state.shape === Shape.Circle) backingShape = "Round/Circular";
    if (state.shape === Shape.Oval) backingShape = "Oval";

    backingDesc = `Solid Wood Backing Board. Material: ${tone}. Edge: ${edge}. Shape: ${backingShape} (following the contour of the metal plaque with a small border). The metal plate is centered on this wood base.`;
  }

  let hardwareDesc = "Hidden adhesive (VHB) - Floating appearance";
  if (state.fixing === Fixing.Screws || state.fixing === Fixing.Caps) {
    const isRect = state.shape === Shape.Rect;
    // Rectangles have 4 fixings in corners; Oval/Circle have 2 fixings at 3 and 9 o'clock.
    const count = isRect ? "4x" : "2x";
    const pos = isRect 
      ? "in the four corners" 
      : "at the horizontal center lines (left and right edges)";
    
    if (state.fixing === Fixing.Screws) {
      hardwareDesc = `${count} Countersunk Screws positioned ${pos}. Material: ${mat.name}.`;
    } else {
      hardwareDesc = `${count} Decorative Dome Caps positioned ${pos}. Diameter: ${state.capSize}mm. Material: ${mat.name}.`;
    }
  }

  // 3. Structured Prompt
  const prompt = `
    Generate a high-definition, photorealistic product image (Mockup).
    
    INPUT IMAGE INSTRUCTION (CRITICAL):
    - The ATTACHED IMAGE is a high-contrast STENCIL MASK.
    - It contains vector geometry (paths) for the text and DECORATIVE BORDER LINES.
    - You must use the attached image as a STENCIL MASK for the engraving.
    - DO NOT change the font, font weight, or letter shapes.
    - **MUST ENGRAVE:** Any border lines or shapes visible in the mask must be deeply etched into the metal.
    - Preserve the exact layout and positioning.

    SCENE SPECIFICATION:
    - View: Close-up product shot, angled 15 degrees.
    - Lighting: Studio lighting causing realistic specular highlights on the metal.
    - Background: Clean white/plaster wall.

    PHYSICAL PROPERTIES:
    - Material: ${mat.name} (${mat.hex}).
    - Texture: ${mat.texture} with ${mat.details}.
    - Shape: ${shapeDesc}.
    - Backing: ${backingDesc}.
    - Hardware: ${hardwareDesc}.
    - Engraving Style: Deep Etch, filled with Black Enamel.
  `;

  try {
    const response = await retryWrapper(async () => {
      return await ai.models.generateContent({
        model: "gemini-3-pro-image-preview",
        contents: {
          parts: [
            { text: prompt },
            { 
              inlineData: {
                mimeType: "image/png",
                data: svgBase64
              }
            }
          ]
        },
        config: {
          imageConfig: {
            imageSize: "2K", 
            aspectRatio: "4:3"
          }
        }
      });
    });

    if (response.candidates && response.candidates[0].content && response.candidates[0].content.parts) {
       for (const part of response.candidates[0].content.parts) {
         if (part.inlineData) {
           return part.inlineData.data;
         }
       }
    }
    return null;

  } catch (error) {
    console.error("Image generation failed:", error);
    throw error;
  }
};