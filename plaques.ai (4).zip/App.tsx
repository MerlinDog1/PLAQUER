import React, { useState, useRef, useEffect } from 'react';
import { Header } from './components/Header';
import PlaquePreview from './components/PlaquePreview';
import { Controls } from './components/Controls';
import { RealisticPreviewModal } from './components/RealisticPreviewModal';
import { VectorSketch } from './components/VectorSketch';
import { INITIAL_STATE, PlaqueState } from './types';
import { generateLayout, generateRealisticView } from './services/geminiService';
import { downloadCorelSvg, downloadPdf, svgToPngBase64 } from './services/exportService';

const App: React.FC = () => {
  const [hasAccess, setHasAccess] = useState(false);
  const [isCheckingAccess, setIsCheckingAccess] = useState(true);
  const [currentView, setCurrentView] = useState<'plaque' | 'vector'>('plaque');

  const [state, setState] = useState<PlaqueState>(INITIAL_STATE);
  const [isGeneratingLayout, setIsGeneratingLayout] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  
  const svgRef = useRef<SVGSVGElement>(null);

  // --- Auth & Startup Logic ---
  useEffect(() => {
    const checkAccess = async () => {
      try {
        const hasKey = await (window as any).aistudio.hasSelectedApiKey();
        setHasAccess(hasKey);
      } catch (e) {
        console.error("Failed to check API key status", e);
        setHasAccess(false);
      } finally {
        setIsCheckingAccess(false);
      }
    };
    checkAccess();
  }, []);

  const handleConnectApiKey = async () => {
    try {
      await (window as any).aistudio.openSelectKey();
      setHasAccess(true);
    } catch (e) {
      console.error("API Key selection failed", e);
      alert("Failed to connect API Key. Please try again.");
    }
  };

  const handleApiError = (error: any) => {
    const msg = error?.toString()?.toLowerCase() || "";
    if (msg.includes("permission_denied") || msg.includes("403") || msg.includes("requested entity was not found")) {
      setHasAccess(false); // Reset access to force re-selection
      alert("Session expired or invalid permissions. Please reconnect your API key (Must be a paid project for Image Generation).");
    } else {
      alert("AI Generation failed: " + (error.message || "Unknown error"));
    }
  };

  // --- Core App Logic ---

  const price = React.useMemo(() => {
    const area = (state.width * state.height) / 100; // cm2
    const base = 40;
    const materialFactor = state.material.includes('brass') ? 1.5 : 1.2;
    const woodCost = state.wood ? 25 : 0;
    return Math.round((base + (area * 0.2) * materialFactor + woodCost));
  }, [state.width, state.height, state.material, state.wood]);

  const handleStateChange = (changes: Partial<PlaqueState>) => {
    setState(prev => ({ ...prev, ...changes }));
  };

  const handleClearDesign = () => {
    setState(prev => ({
      ...prev,
      generatedSvgContent: null,
      aiReasoning: null
    }));
  };

  const handleGenerateLayout = async (prompt: string) => {
    setIsGeneratingLayout(true);
    try {
      const result = await generateLayout(
        prompt, 
        state.width, 
        state.height, 
        state.shape, 
        state.generatedSvgContent
      );
      
      if (result) {
        setState(prev => ({
          ...prev,
          generatedSvgContent: result.svgContent,
          aiReasoning: result.reasoning
        }));
      }
    } catch (error) {
      handleApiError(error);
    } finally {
      setIsGeneratingLayout(false);
    }
  };

  const handleRealPreview = async () => {
    if (!svgRef.current) return;
    setModalOpen(true);
    setGeneratedImage(null);
    setIsGeneratingImage(true);

    try {
      const base64Png = await svgToPngBase64(svgRef.current);
      const result = await generateRealisticView(base64Png, state);
      setGeneratedImage(result);
    } catch (error) {
      handleApiError(error);
      setModalOpen(false);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleExportSvg = async () => {
    if (!svgRef.current) return;
    await downloadCorelSvg(svgRef.current, state);
  };

  const handleExportPdf = async () => {
    if (!svgRef.current) return;
    await downloadPdf(svgRef.current, state);
  };

  const handleNativePrint = () => {
    window.print();
  };

  // --- Render ---

  if (isCheckingAccess) {
    return (
      <div className="min-h-screen bg-brand-dark flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-4 border-brand-accent border-t-transparent rounded-full animate-spin"></div>
          <p className="text-gray-400 text-sm font-medium">Initializing Plaques AI...</p>
        </div>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-brand-dark flex flex-col items-center justify-center p-4 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-accent/5 rounded-full blur-[120px] pointer-events-none" />
        
        <div className="max-w-md w-full glass-panel p-8 rounded-2xl border border-gray-800 shadow-2xl relative z-10 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-brand-accent to-yellow-600 rounded-xl mx-auto flex items-center justify-center text-brand-dark font-bold text-3xl mb-6 shadow-lg shadow-brand-accent/20">
            P
          </div>
          
          <h1 className="text-3xl font-serif text-white mb-2 tracking-tight">plaques<span className="text-brand-accent">.ai</span></h1>
          <p className="text-gray-400 text-sm mb-8 leading-relaxed">
            Welcome to the Pro Designer. To access high-fidelity realistic previews and AI layout generation, please connect your Google Cloud Project.
          </p>

          <div className="space-y-4">
            <button 
              onClick={handleConnectApiKey}
              className="w-full py-3.5 bg-white text-brand-dark font-bold rounded-xl hover:bg-gray-100 transition-all transform hover:scale-[1.02] shadow-xl flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5 text-brand-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
              </svg>
              Connect API Key
            </button>
            
            <p className="text-[10px] text-gray-500">
              Requires a paid project for Veo/Image generation models. <br/>
              <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-brand-accent hover:underline">
                View billing documentation
              </a>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-dark flex flex-col">
      <Header currentView={currentView} onNavigate={setCurrentView} />
      
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 md:p-8 flex flex-col lg:flex-row gap-8">
        
        {currentView === 'vector' ? (
          <VectorSketch />
        ) : (
          <>
            {/* Left Column: Preview (Sticky on Desktop) */}
            <section className="flex-1 lg:flex-[1.5] relative">
              <div className="lg:sticky lg:top-24 space-y-6">
                
                <div className="flex items-center justify-between no-print">
                   <h2 className="text-2xl font-serif text-white">Design Studio</h2>
                   <div className="flex gap-2">
                     <button 
                       onClick={handleRealPreview}
                       className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold rounded-lg shadow-lg shadow-emerald-900/50 transition-all flex items-center gap-2"
                     >
                       <span>📷</span> Realistic View
                     </button>
                     <div className="flex rounded-lg bg-[#2a2d3a] border border-gray-700 p-0.5">
                       <button 
                         onClick={handleExportSvg}
                         className="px-3 py-1.5 hover:bg-[#333644] text-gray-200 text-sm font-medium rounded-md transition-all border-r border-gray-600"
                       >
                         SVG
                       </button>
                       <button 
                         onClick={handleExportPdf}
                         className="px-3 py-1.5 hover:bg-[#333644] text-gray-200 text-sm font-medium rounded-md transition-all border-r border-gray-600"
                       >
                         PDF (Pro)
                       </button>
                       <button 
                         onClick={handleNativePrint}
                         className="px-3 py-1.5 hover:bg-[#333644] text-gray-200 text-sm font-medium rounded-md transition-all flex items-center gap-1"
                         title="Use browser print dialog to save as PDF"
                       >
                         <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                         Print
                       </button>
                     </div>
                   </div>
                </div>

                <PlaquePreview ref={svgRef} state={state} />
                
                <div className="flex justify-center gap-8 text-sm text-gray-500 font-mono no-print">
                  <span>{state.width}mm × {state.height}mm</span>
                  <span className="text-gray-700">|</span>
                  <span className="capitalize">{state.material.replace('-', ' ')}</span>
                </div>

                {/* Price Card Mobile/Desktop */}
                <div className="mt-8 p-6 rounded-2xl bg-gradient-to-r from-gray-900 to-gray-800 border border-gray-700 flex items-center justify-between no-print">
                  <div>
                    <p className="text-gray-400 text-sm mb-1">Estimated Total</p>
                    <div className="text-3xl font-bold text-white">${price}.00</div>
                  </div>
                  <button className="px-8 py-3 bg-brand-accent hover:bg-yellow-400 text-black font-bold rounded-xl shadow-lg shadow-yellow-500/20 transition-all transform hover:scale-105">
                    Add to Cart
                  </button>
                </div>
              </div>
            </section>

            {/* Right Column: Controls */}
            <aside className="flex-1 lg:max-w-md no-print">
               <Controls 
                 state={state} 
                 onChange={handleStateChange} 
                 onGenerate={handleGenerateLayout}
                 onClear={handleClearDesign}
                 isGenerating={isGeneratingLayout}
               />
            </aside>
          </>
        )}
      </main>

      <div className="no-print">
        <RealisticPreviewModal 
          isOpen={modalOpen} 
          onClose={() => setModalOpen(false)}
          isLoading={isGeneratingImage}
          imageUrl={generatedImage}
        />
      </div>
    </div>
  );
};

export default App;